package com.trip.TripProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
