package com.trip.TripProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripProjectApplication.class, args);
	}

}
